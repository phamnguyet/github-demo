<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite 2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>10fe1de4-3347-4710-9e3b-baeb585c8d1f</testSuiteGuid>
   <testCaseLink>
      <guid>f42db357-386f-44b2-be27-824da0565b87</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case 2</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>12ce0abb-e4c5-446b-916d-23b950b76125</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Login</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>12ce0abb-e4c5-446b-916d-23b950b76125</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>User_Name</value>
         <variableId>dfe5d06d-204e-4b0d-9cb5-298b0212e312</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>12ce0abb-e4c5-446b-916d-23b950b76125</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Password</value>
         <variableId>37ee8de5-2319-4284-8bcc-25a3ddf000f2</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
