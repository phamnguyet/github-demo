import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebElement as WebElement

'Go to url https://zingmp3.vn/'
WebUI.openBrowser('https://zingmp3.vn/')

'Verify search box display'
WebUI.verifyElementVisible(findTestObject('Home_Zing/txt_Search'))

'Close popup'
WebUI.click(findTestObject('Home_Zing/icon_popup'))

'Click to the search box'
WebUI.click(findTestObject('Home_Zing/txt_inputSearch'))

'Input \'abc\' to the search field'
WebUI.sendKeys(findTestObject('Home_Zing/txt_inputSearch'), 'abc')

'Find list songs suggest'
TestObject testObj = findTestObject('Home_Zing/list_Suggest')

'Get list song suggest'
List<WebElement> elements = WebUI.findWebElements(testObj, 10)

int i = 0

'Verify list songs have contains text \'abc\''
while (i < elements.size()) {
    String Song = (elements[i]).getText().toLowerCase()

    i++

    if (Song.contains('abc')) {
        System.out.println('Title song as' + Song)

        assert true
    } else {
        assert false
    }
}

WebUI.closeBrowser()

