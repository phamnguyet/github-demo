package custom
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable







class Login {
	@Keyword
	def login() {
		WebUI.openBrowser(null)
		WebUI.maximizeWindow()
		WebUI.navigateToUrl(GlobalVariable.BASE_URL)
		WebUI.sendKeys(findTestObject('Page_Katalon/txt_Email'),GlobalVariable.USER_NAME)
		WebUI.setEncryptedText(findTestObject('Page_Katalon/txt_Password'),GlobalVariable.PASSWORD, FailureHandling.OPTIONAL)
		WebUI.click(findTestObject('Page_Katalon/btn_SignIn'))
	}
}