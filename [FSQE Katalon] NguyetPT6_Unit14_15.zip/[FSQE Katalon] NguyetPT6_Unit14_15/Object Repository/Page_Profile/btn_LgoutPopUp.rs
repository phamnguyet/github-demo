<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_LgoutPopUp</name>
   <tag></tag>
   <elementGuidId>d0d295e0-a272-4030-92b4-d41d0da0d132</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value> //button[contains(text(),'Log Out')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
