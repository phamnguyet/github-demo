package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object BASE_URL
     
    /**
     * <p></p>
     */
    public static Object USER_NAME
     
    /**
     * <p></p>
     */
    public static Object PASSWORD
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters())
    
            BASE_URL = selectedVariables['BASE_URL']
            USER_NAME = selectedVariables['USER_NAME']
            PASSWORD = selectedVariables['PASSWORD']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
