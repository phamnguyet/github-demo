import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.WebElement

import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.openBrowser('https://zingmp3.vn/')

WebUI.maximizeWindow()

List<WebElement> closeModal = WebUiCommonHelper.findWebElements(findTestObject('Object Repository/Zing MP3/i_closeModal'), 10)
if (closeModal.size() != 0) {
WebUI.click(findTestObject('Object Repository/Zing MP3/i_closeModal'))
}

WebUI.verifyElementVisible(findTestObject('Object Repository/Zing MP3/input_searchBox'))

WebUI.click(findTestObject('Object Repository/Zing MP3/input_searchBox'))

WebUI.setText(findTestObject('Object Repository/Zing MP3/input_searchBox'), 'abc')

List<WebElement> songResults = WebUiCommonHelper.findWebElements(findTestObject('Object Repository/Zing MP3/li_suggestResults'), 10)

for (int i = 0; i < songResults.size(); i++) {
	String suggestion = WebUI.getText(WebUI.convertWebElementToTestObject(songResults[i])).toLowerCase()
	if (suggestion.contains('abc')) {
	assert true
	} else {
	assert false
	}
}


