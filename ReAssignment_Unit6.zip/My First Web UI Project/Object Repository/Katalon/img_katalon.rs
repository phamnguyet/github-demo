<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>//img[@alt=&quot;Katalon Logo&quot;]</description>
   <name>img_Katalon</name>
   <tag></tag>
   <elementGuidId>044243f5-b2b4-4c64-bc95-38c819e5f76f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//img[@alt=&quot;Katalon Logo&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
