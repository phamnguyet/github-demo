import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When



class loginSteps {

	@Given("Navigate to the Sign-In Page")
	def navigatetoSignInPage() {
		WebUI.openBrowser('https://katalon.com/sign-in')
		
		WebUI.maximizeWindow()
		
	}
	
	@When("I enter username (.*) and password (.*)")
	def enterValidUserNameandPassword(String username, String password) {
		
		WebUI.sendKeys(findTestObject('Page_Login/ip_Email'), username)
		
		WebUI.setEncryptedText(findTestObject('Page_Login/ip_Password'),password)
		
	}
	
	@And("I click Sign-In button")
	def clickBtnSignIn() {
		WebUI.click(findTestObject('Page_Login/btn_SignIn'))
	
	}
	
	@Then("I should be able to login successfully")
	def showtextMyAcount() {
		WebUI.verifyElementVisible(findTestObject('Page_Home/a_MyAcount'))
	}
	
	@And("I click the My Account")
	def clicktxtMyAcount() {
		WebUI.click(findTestObject('Page_Home/a_MyAcount'))
		
	}
	
	@And("I go to the Home Page")
	def gotoHomePage() {
		String url = WebUI.getUrl()
		if (url.contains('https://my.katalon.com/home')) {
			assert true
			System.out.println('Go to Home page successfully')
		} else {
			assert false
			System.out.println('Go to Home page unsucessfully')
		}
		
	}
	
	@And("Click Manage your profile on the Home screen")
	def clickManageProfile() {
		WebUI.click(findTestObject('Page_Home/a_txtManageProfile'))
		
	}
	
	
	@And("I clicks icon Avatar")
	def clickIconAvatar() {
		WebUI.click(findTestObject('Page_Home/icon_Avatar'))
		
	}
	
	@Then("I verify UserName show corecttly with username (.*)")
	def showUserName(String username) {
		
		'Get text user name'
		String result = WebUI.getText(findTestObject('Page_Home/txt_UserName'))
				
		'Verify account input match with account is showing at the profile page'
		WebUI.verifyMatch(username, result, true)	
		
	}
	
	@Then("I verify show corecttly username (.*)")
	def showEmail(String username) {
		
		'Get text email'
		String email = WebUI.getText(findTestObject('Page_Profile/p_txtEmail', [('email') : 'phamnguyet5620@gmail.com']))
				
		'Verify account input match with account is showing at the profile page'
		WebUI.verifyMatch(username, email, true)
		
	}
	
	@And("I perform logout page")
	def logOut() {
		'Click icon Log Out'
		WebUI.click(findTestObject('Page_Profile/a_LogOut'))
		
		'Verify display dialog'
		WebUI.verifyElementVisible(findTestObject('Page_Profile/a_dialogLogOut'))
		
		WebUI.verifyElementVisible(findTestObject('Page_Profile/btn_LogOut'))
		
		'Click button Logout on popup'
		//WebUI.click(findTestObject('Page_Profile/btn_LogOut'))
		WebUI.click(findTestObject('Page_Profile/btn_LogOut'))
		
	}
	
	@Then("I should NOT be able to login successfully")
	def showMgsErrorLogin() {
		WebUI.verifyElementVisible(findTestObject('Page_Login/div_msgLoginError'))
	}
	
	@Then("I should be able to logout successfully")
	def showTxtSignIn() {
		WebUI.verifyElementVisible(findTestObject('Page_Home/div_txtSignIn'))
	}
	
	@And("I close browser")
	def closeBrowser() {
		WebUI.closeBrowser()
	}
	
	
}